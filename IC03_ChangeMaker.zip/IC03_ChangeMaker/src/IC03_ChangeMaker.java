import java.util.Scanner;

public class IC03_ChangeMaker {

	public static void main(String[] args) {
		//Step 1: Declare all variables
		
		int number, quarter, dime, nickel, penny;
		Scanner consoleScanner = new Scanner(System.in);
		// Step 2: Prompt user for input
		
		System.out.println("Enter a whole number from 1 to 99.\n"
				+ "I will find a combination of coins to equal that amount of change");
		number = consoleScanner.nextInt();
		
		// Step 3: Any calculation
		
		quarter = number/25;
		dime = (number % 25 )/10;
		nickel = ((number % 25)%10)/5;
		penny = ((number%25)%10)%5;
		
		//Step 4: Results
		
		System.out.println("\n"+ number + " cents in coins can be given as:\n"
				+ quarter + " quarter(s)\n"
				+ dime + " dime(s)\n"
				+ nickel + " nickel(s)\n"
				+ penny + " penny(ies)");
		
		consoleScanner.close();

	}

}
