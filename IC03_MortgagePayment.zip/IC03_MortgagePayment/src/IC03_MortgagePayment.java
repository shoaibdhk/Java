import java.text.NumberFormat;
import java.util.Scanner;

public class IC03_MortgagePayment {

	public static void main(String[] args) {
		// Step 1: Declare the variables
		
		double mortgage, outstanding, interest, principal;
		Scanner consoleScanner = new Scanner(System.in);
		NumberFormat currency = NumberFormat.getCurrencyInstance();
		
		//Step 2: Prompt for user input
		
		System.out.print("Please enter your mortgage payment: $");
		mortgage = consoleScanner.nextDouble();
		
		System.out.print("Please enter outstanding balance on mortgage: $");
		outstanding = consoleScanner.nextDouble();
		
		
		// Step 3: Perform any calculation
		interest = ((outstanding*0.04)/12);
		principal = mortgage - interest;
		
		// Step 4: Perform any method and results
		
		System.out.print("\nOf your $"+currency.format(mortgage)+ " mortgage payment:\n"
				+ currency.format(interest)+ " goes to interest\n"
				+ currency.format(principal)+ " goes to principal");
		
		
		consoleScanner.close();

	}

}
