import java.util.Scanner;

public class IC04_DateFormat
{

    public static void main(String[] args)
    {
        // Step 1: Declare any variable needed
        String date;
        Scanner consoleScanner= new Scanner(System.in);

        // Step 2: Prompt user for input
        System.out.println("Please enter the date (formate MM/DD/YYYY and include the forward slashes:");
        date = consoleScanner.nextLine();

        // Step 3: Do any calculation

        //Step 4: perform any method

        System.out.println("\nIn European format, DD.MM.YYYY, this date is:\n"
                + date.substring(3,5)+"."+date.substring(0,2)+"."+date.substring(6)      );



    }

}
