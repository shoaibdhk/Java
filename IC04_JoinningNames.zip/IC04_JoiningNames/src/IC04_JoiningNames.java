import java.util.Scanner;

public class IC04_JoiningNames
{

    public static void main(String[] args)
    {
        // Step 1: declare all needed variables

       String first, middle, last;
       //Ctrl+ Shift+ o => Auto import
       Scanner consoleScanner = new Scanner(System.in);

       // Step 2: Prompt user for input
       System.out.print("Please enter your first name: ");
       first= consoleScanner.nextLine();
       System.out.print("Please enter your middle name initial: ");
       middle= consoleScanner.nextLine();
       System.out.print("Please enter your last name: ");
       last= consoleScanner.nextLine();

       // Step 3: Perform any calculation

       //Step 4: Perform any method

       System.out.println("\n" + first +"(length= "+ first.length()+ ")"
         + "\n" + middle +"(length= "+ middle.length() + ")"
        + "\n" + last +"(length= "+ last.length() + ")"+
         "\n\n"+ last.toUpperCase()+ ","+ first.toUpperCase() + "," + middle.toUpperCase());

       consoleScanner.close();
    }

}
