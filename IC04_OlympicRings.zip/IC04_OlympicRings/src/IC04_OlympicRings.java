import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JApplet;

// 1. Tell java we're making an Applet (not console app)
public class IC04_OlympicRings extends JApplet
{

    // Two entry points (init and paints)

    public void init()
    {
        // init sets the size of your canvas
        setSize(400,300);
    }

    public void paint(Graphics canvas)
    {
        // [NOT ON QUIZ] How to thicken the line
        Graphics2D canvas2D= (Graphics2D) canvas;
        canvas2D.setStroke(new BasicStroke(5));

        // to change the color use canvas.setColor
        canvas.setColor(Color.blue);
        canvas.drawOval(0, 0, 100, 100);

        canvas.setColor(Color.YELLOW);
        canvas.drawOval(52, 52, 100, 100);

        canvas.setColor(Color.BLACK);
        canvas.drawOval(110, 0, 100, 100);

        canvas.setColor(Color.green);
        canvas.drawOval(170, 52, 100, 100);

        canvas.setColor(Color.RED);
        canvas.drawOval(220, 0, 100, 100);
    }

}
