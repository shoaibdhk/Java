import java.awt.Graphics;

import javax.swing.JApplet;

public class IC04_Snowman extends JApplet {
	 public void init()
	    {
	        // set the size of your canvas
	        setSize(400,300);
	    }
	 public void paint(Graphics canvas)
	 {
		 canvas.drawOval(35,10,50,50);
		 canvas.fillOval(45, 20, 10, 10);
		 canvas.fillOval(65, 20, 10, 10);
		 canvas.drawArc(45, 30, 30, 15, 180, 180);
		 canvas.drawOval(21, 60, 75, 75);
		 canvas.drawOval(8, 135, 100, 100);		 
	 }
}
