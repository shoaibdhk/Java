import java.text.DecimalFormat;
import java.util.Scanner;

public class IC05_BloodAlcoholContent
{
    public static final double OUNCES_ALCOHOL = 1.5;
    public static final double BAC_LIMIT = 0.08;
    public static void main(String[] args)
    {
        //Step 1: Declare variables
        double numberOfDrinks, weight, bac;
        Scanner consoleScanner = new Scanner (System.in);
        DecimalFormat threeDPs = new DecimalFormat("0.000");

        //Step 2: Prompt user to input

        System.out.print("Enter the number of alcohol drinks consumed: ");
        numberOfDrinks = consoleScanner.nextInt();

        System.out.print("Please enter your weight in lbs: ");
        weight = consoleScanner.nextInt();
        consoleScanner.close();
        bac = (4.136 * numberOfDrinks * OUNCES_ALCOHOL)/weight;

        if (bac>=0.08)
            System.out.println("\nYour BAC is "+ threeDPs.format(bac)
            + "\nAccording to the state of California, you are intoxicated. Do not drive!");
        else
            System.out.println("\nYour BAC is "+ threeDPs.format(bac)+ "\nYou are safe");

    }

}
