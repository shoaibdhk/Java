import java.util.Scanner;

public class IC05_IncreasingNumbers
{

    public static void main(String[] args)
    {
        int num1, num2, num3, min, med, max;
        Scanner consoleScanner= new Scanner(System.in);
       System.out.print("Please enter a non-negaive number: ");
       num1= consoleScanner.nextInt();

       System.out.print("Please enter a non-negaive number: ");
       num2 = consoleScanner.nextInt();

       System.out.print("Please enter a non-negaive number: ");
       num3 = consoleScanner.nextInt();

       consoleScanner.close();
       max = 0; med = 0; min = 0;
       System.out.println("The numbers you entered in increasing order are:");
        
       if (num1 > num2 && num1 > num3) {
        	max = num1;
        	if (num2> num3) {
        		med = num2;
        		min = num3;
        	}else {
        		med = num3;
        		min = num2;
        	}
        	
        } else if (num2> num1 && num2 > num3) {
        	max = num2;
        	med = (num1> num3) ? num1: num3;
        	min = (num1 > num3)? num3: num1;
        	
        } else if (num3 > num1 && num3> num2) {
        	max= num3;
        	med = (num1> num2) ? num1 : num2;
        	min = (num1> num2) ? num2 : num1;
        }

        System.out.println(min + "\n" + med + "\n" + max);
    }

}