import java.util.Scanner;

public class HackerChallenge {
	public static void main(String[] args)
    {
        String date, monthPart, dayPart, yearPart;
        int month, day, year;
        Scanner consoleScanner = new Scanner(System.in);
        
        // Prompt user for input
        System.out.println("Please enter date in the form MM/DD/YYYY");
        date = consoleScanner.next();
        consoleScanner.close();
        
        monthPart = date.substring(0,2);
        dayPart = date.substring(3, 5);
        yearPart = date.substring(6);
        
        month = Integer.parseInt(monthPart);
        day = Integer.parseInt(dayPart);
        year = Integer.parseInt(yearPart);
        System.out.println();
        if (year>=0000 && year<= 9999) {
	        	switch (month) {
	            case 1: case 3: case 5:
	            case 7: case 8: case 10:
	            case 12:
	                if (day>=1 && day<=31)
	                	System.out.println("This is a valid date.");
	                else 
	                	System.out.println("Invalid day.");
	                break;
	            case 4: case 6:
	            case 9: case 11:
	                if (day>=1 && day<=30)
	                	System.out.println("This is a valid date.");
	                else
	                	System.out.println("Invalid day.");
	                break;
	            case 2:
	                if (day>=1 && day <=29)
	                	if (((year % 4 == 0) && !(year % 100 == 0)) || (year % 400 == 0))
	                    System.out.println("This is a leap year and valid date");
	                	else if (day>=1 && day<=28)
	                	System.out.println("This is a valid date");
	                else 
	                	System.out.println("Invalid day");
	                    
	                break;
	            default:
	                System.out.println("Invalid month.");
	                break;
	        }
	    } else 
	    	System.out.println("Invaid year");
    }
}
