import java.util.Scanner;

public class RockPaperScissors
{

    public static void main(String[] args)
    {
        String p1, p2;
        Scanner consoleScanner = new Scanner(System.in);

       System.out.print("Player 1 (enter R for rock, P for paper, S for scissors):");
       p1 = consoleScanner.next().toUpperCase();

       System.out.print("Player 2 (enter R for rock, P for paper, S for scissors):");
       p2 = consoleScanner.next().toUpperCase();
       
       consoleScanner.close();
       
       
       System.out.println();
       switch (p1)
       {
           case "R":
               switch (p2){
                   case "R":
                       System.out.println("It's a draw!");
                       break;
                   case "P":
                       System.out.println("Player 2 wins! Paper covers rock.");
                       break;
                   case "S":
                   System.out.println("Player 1 wins! Rock breaks scissors.");
               }
               break;
           case "P":
               switch(p2){
                   case "R":
                       System.out.println("Player 1 wins! Paper covers rock.");
                       break;
                   case "P":
                       System.out.println("It's a draw!");
                       break;
                   case "S":
                       System.out.println("Player 2 wins! Scissors cut paper.");

               }
               break;
           case "S":
               switch (p2){
                   case "R":
                       System.out.println("Player 2 wins! Rock breaks scissors.");
                       break;
                   case "P":
                       System.out.println("Player 1 wins! Scissors cut paper.");
                       break;
                   case "S":
                       System.out.println("It's a draw!");
               }
       }
    }

}
