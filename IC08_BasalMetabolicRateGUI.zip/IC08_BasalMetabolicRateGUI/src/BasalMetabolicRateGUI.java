import java.text.DecimalFormat;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class BasalMetabolicRateGUI extends JFrame
{
    public static final int CHOCOLATE_BAR_CALORIES= 230;
    public static void main(String[] args)
    {
        // Step 1: Declare any needed variable

        double weight, height, age, bmr, bars;
        int gender;
        String activity;
        DecimalFormat noDP= new DecimalFormat("0");
        DecimalFormat oneDPs= new DecimalFormat("0.0");


        // Step:2 Prompt user for input

        weight=Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter your weight (lb): "));

        height = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter your height in inches: "));

        age = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter you age in years: "));

        //custom buttons
        String[] buttons = {"Female", "Male"};

        gender = JOptionPane.showOptionDialog(
                null,
                "Calculate BMR for Female or Male",
                "Identify Gender",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                buttons,
                buttons[0]);

        // Let's make a decision to determine gender
        if (gender == 0)
        bmr= 655 + (4.35*weight) + (4.7* height) - (4.7* age);
        else
        bmr = 66 + (6.23* weight) + (12.7* height) - (6.8* age);



        String[] options = {
        			"Sedentary",
        		"Somewhat active",
        			"Active",
        		"Highly Active"};
        Object slectedValue = JOptionPane.showInputDialog(null,
                "Select activity level",
                "BMR Activity level",
                JOptionPane.INFORMATION_MESSAGE,null,options, options[0]);
        activity = slectedValue.toString();
        switch(activity){
            case "Sedentary":
            bmr*=1.2;
            break;
            case "Somewhat active":
            bmr*= 1.3;
            break;
            case "Active":
            bmr*= 1.4;
            break;
            case "Highly Active":
            bmr*=1.5;}
      //calculating chocolate bars for female and male
        bars = bmr/CHOCOLATE_BAR_CALORIES;

        JOptionPane.showMessageDialog(null,"As a "+ buttons[gender]+" your BMR x Activity Factor is " + noDP.format(bmr) + " and you need to eat\n"+ oneDPs.format(bars)
        + " choclate bars" + "to maintain this amount of calories.");

    }

}
