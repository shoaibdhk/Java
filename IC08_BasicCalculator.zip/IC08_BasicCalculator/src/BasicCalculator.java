import java.util.Scanner;

public class BasicCalculator {

	public static void main(String[] args) {
		double num1, num2, result = 0; String operator;
		Scanner scnr = new Scanner(System.in);
		
		System.out.println( "**********************************************************************\n" +
							"**                                                                  **\n" +
							"**                 WELCOME TO MIKE'S BASIC CALCULATOR               **\n" +
							"**                                                                  **\n" +
							"**********************************************************************\n" +
							"Type one of the following operators:\n+" +
							" +   (for adding numbers)\n" + 
							" -   (for substrating numbers)\n" + 
							" *   (for multiplying numbers)\n" + 
							" /   (for dividing numbers)\n" +
							" %   (for finding the remainder when two numbers are divided)\n"+
							" ^   (for exponentiation - one number raised to the power of the other)\n" +
							"***********************************************************************");
		operator = scnr.nextLine();
		
		System.out.print("Enter and operand (number): ");
		num1= scnr.nextDouble();
		System.out.print("Enter and operand (number): ");
		num2 = scnr.nextDouble();
		scnr.close();
		
		/*if (operator.equals("+")) {
			result = num1+num2;
			System.out.println(num1 + " + " + num2 + " = " + result );
		} else if (operator.equals("-")) {
			result = num1 - num2;
			System.out.println(num1 + " - " + num2 + " = " + result );
		} else if (operator.equals("*")) {
			result = num1 * num2;
			System.out.println(num1 + " * " + num2 + " = " + result );
		} else if (operator.equals("/")) {
			result = num1 / num2;
			System.out.println(num1 + " / " + num2 + " = " + result );
		} else if (operator.equals("%")) {
			result = num1 % num2;
			System.out.println(num1 + " % " + num2 + " = " + result );
		} else if (operator.equals("^")) {
			result = Math.pow(num1, num2);
			System.out.println(num1 + " ^ " + num2 + " = " + result );
		} else 
			System.out.println("Error!  Operator undefined in this version of the calculator.");
		
		 */
		switch (operator) 
		{
			case "+" : 
				result = num1+num2;
				System.out.println(num1 + " + " + num2 + " = " + result );
				break;
			case "-" :
				result = num1 - num2;
				System.out.println(num1 + " - " + num2 + " = " + result );
				break;
			case "*":
				result = num1 * num2;
				System.out.println(num1 + " * " + num2 + " = " + result );
				break;
			case "/" :
				result = num1 / num2;
				System.out.println(num1 + " / " + num2 + " = " + result );
				break;
			case "%" :
				result = num1 % num2;
				System.out.println(num1 + " % " + num2 + " = " + result );
				break;
			case "^" :
				result = Math.pow(num1, num2);
				System.out.println(num1 + " ^ " + num2 + " = " + result );
				break;
			default :
				System.out.println("Error!  Operator undefined in this version of the calculator.");
				
				
		}
		

	}

}
