import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ChangeMakerGUI extends JFrame{

	public static void main(String[] args) {
		//Step 1: Declare all variables

		int number, quarter, dime, nickel, penny;
		// Step 2: Prompt user for input
		// parent window, message, caption
		// showInputDialog returns a String
		// we use Integer.parseInt to convert the String to Integer
		number = Integer.parseInt(JOptionPane.showInputDialog(null, "Please enter number of cents between 1 to 99:"));

		// Step 3: Any calculation

		quarter = number/25;
		dime = (number % 25 )/10;
		nickel = ((number % 25)%10)/5;
		penny = ((number%25)%10)%5;

		//Step 4: Results

		JOptionPane.showMessageDialog(null, number + " cents in coins can be given as:\n"
				+ quarter + " quarter(s)\n"
				+ dime + " dime(s)\n"
				+ nickel + " nickel(s)\n"
				+ penny + " penny(ies)");

	}

}
