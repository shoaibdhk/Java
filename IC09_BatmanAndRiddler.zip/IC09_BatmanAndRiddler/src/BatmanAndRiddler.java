public class BatmanAndRiddler 
{

	public static void main(String[] args) 
	{
		for (int address = 1001; address <= 9999; address += 2) // the number is odd
		{
		    
		    int i4 = address % 10;
		    int i3 = address / 10 % 10;
		    int i2 = address / 100 % 10;
		    int i1 = address / 1000 % 10;
		    
		    
		    if (i1 != (i3 * 3))	
		    	continue;

		    if (i1 != i2 && i1 != i3 && i1 != i4 && i2 != i3 && i2 != i4 && i3 != i4)
		    	
		    if ((i1 + i2 + i3 + i4) == 27)
		            System.out.println("The Riddler intends to strike " + address + " Pennsylvania Avenue.");
		}
	}
}