import java.util.Scanner;

public class CountVonCount
{

    public static void main(String[] args)
    {
        int num;
        Scanner consoleScanner = new Scanner(System.in);

        System.out.println("Count von Count:  What is the magic number of the day?");
        num = consoleScanner.nextInt();
        consoleScanner.close();

        if (num<1){
            System.err.println("I'm sorry, but the Count von Count only counts positive numbers!  Muhahahaha");
            System.exit(0);
        }
            for (int i = 1; i < num; i++){

                    System.out.print(i + ", ");

            }
            System.out.println(num);
            System.out.println(num + "! " + num + " is the number of the day. " +
            num + " dancing vegetables are here to celebrate with me!  I love dancing vegetables!");



    }

}
