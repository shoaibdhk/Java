import java.util.Random;
import java.util.Scanner;

public class HackerChallenge
{

    public static void main(String[] args)
    {
        String response, ques ; int answer,outcome;
        Scanner scnr = new Scanner(System.in);
        Random rng  = new Random();
        

        do{
            System.out.println("What question would you like to ask the Magic 8 ball?\n");
            ques = scnr.nextLine();
            answer = rng.nextInt(20)+1;
            System.out.print("The answer is: ");
            switch(answer){
                case 1:
                    System.out.println("It is certain");
                    break;
                case 2:
                    System.out.println("As I see it, yes");
                    break;
                case 3:
                    System.out.println("Don't count on it");
                    break;
                case 4:
                    System.out.println("It is decidedly so");
                    break;
                case 5:
                    System.out.println("Most likely");
                    break;
                case 6:
                    System.out.println("Ask again later");
                    break;
                case 7:
                    System.out.println("My reply is no");
                    break;
                case 8:
                    System.out.println("Without a doubt");
                    break;
                case 9:
                	System.out.println("Outlook good");
                    break;
                case 10:
                	System.out.println("Better not tell you now");
                	break;
                case 11:
                	System.out.println("My sources say no");
                	break;
                case 12:
                	System.out.println("Yes definitely");
                	break;
                case 13:
                	System.out.println("Yep");
                	break;
                case 14:
                	System.out.println("Cannot predict now");
                	break;
                case 15:
                	System.out.println("Outlook not so good");
                	break;
                case 16:
                	System.out.println("You may rely on it");
                	break;
                case 17:
                	System.out.println("Signs point to yes");
                	break;
                case 18:
                	System.out.println("Concentrate and ask again");
                	break;
                case 19:
                	System.out.println("Very doubtful");
                	break;
                case 20:
                	System.out.println("Reply hazy try again");
                	
            }

            outcome = rng.nextInt(20)+1;
            System.out.print("This answer is: ");
            switch(outcome) 
            {
            	case 1:
            		System.out.println("Positive");
            		break;
            	case 2:
            		System.out.println("Positive");
            		break;
            	case 3:
            		System.out.println("Positive");
            		break;
            	case 4:
            		System.out.println("Positive");
            		break;
            	case 5:
            		System.out.println("Positive");
            		break;
            	case 6:
            		System.out.println("Positive");
            		break;
            	case 7:
            		System.out.println("Positive");
            		break;
            	case 8:
            		System.out.println("Positive");
            		break;
            	case 9:
            		System.out.println("Positive");
            		break;
            	case 10:
            		System.out.println("Positive");
            		break;
            	case 11:
            		System.out.println("Neutral");
            		break;
            	case 12:
            		System.out.println("Neutral");
            		break;
            	case 13:
            		System.out.println("Neutral");
            		break;
            	case 14:
            		System.out.println("Neutral");
            		break;
            	case 15:
            		System.out.println("Neutral");
            		break;
            	case 16:
            		System.out.println("Negative");
            		break;
            	case 17:
            		System.out.println("Negative");
            		break;
            	case 18:
            		System.out.println("Negative");
            		break;
            	case 19:
            		System.out.println("Negative");
            		break;
            	case 20:
            		System.out.println("Negative");
            		break;
            		
            }
            System.out.println("Would you like to ask another question (type Y or N)?");
            response = scnr.nextLine().toUpperCase();


        }while(response.startsWith("Y"));

        System.out.println("\nThank you for playing the Magic 8 Ball.");
        scnr.close();

    }

}
