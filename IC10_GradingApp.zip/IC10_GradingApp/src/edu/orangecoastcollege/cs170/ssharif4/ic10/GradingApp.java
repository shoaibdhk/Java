package edu.orangecoastcollege.cs170.ssharif4.ic10;
import java.util.Scanner;

public class GradingApp
{

    public static void main(String[] args)
    {
        double grade, low=Double.MAX_VALUE, average, high= Double.MIN_VALUE, sum = 0;
        int count = 0, numA = 0, numB = 0, numC = 0, numD = 0, numF = 0;
        Scanner consoleScanner = new Scanner(System.in);
        System.out.println("Please input grades one per line (or type -1 to quit):");

        do
        {
            // code repeat
            grade = consoleScanner.nextDouble();


            if (grade > -1)
            {
             // Add 1 to the count
                count++;

                // Add grade to the sum
                sum += grade;
                // Let's determine what grade they got
                if (grade >= 90)
                    numA++;
                else if (grade >= 80)
                    numB++;
                else if (grade >= 70)
                    numC++;
                else if (grade >= 60)
                    numD++;
                else
                    numF++;


                //Let's check to see if the grade is the new low

                if (grade<low)
                    low = grade;
                if (grade>high)
                    high = grade;
            }
        }
        while (grade > -1);
        consoleScanner.close();
        average = sum/count;
        System.out.println("\nThe total numbers of grades= " + count);
        System.out.println("Number of A's= " + numA);
        System.out.println("Number of B's= " + numB);
        System.out.println("Number of C's= " + numC);
        System.out.println("Number of D's= " + numD);
        System.out.println("Number of F's= " + numF);
        System.out.println("Low Grade = " + low+"%");
        System.out.println("Class Average = " + average+"%");
        System.out.println("high Grade = "+ high+"%");


    }

}
