package edu.orangecoastcollege.cs170.ssharif4.ic10;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JApplet;

public class HackerChallenge extends JApplet{
	public void init() {
		setSize(610,600);
	}
	
	public void paint(Graphics canvas) {
		for(int x = 0; x<600; x+=120) {
			for(int y=0; y<=600; y+=60) {
				// Yellow faces
				canvas.setColor(Color.ORANGE);
				canvas.fillOval(x+5, y+0, 60, 60);
				
				canvas.setColor(Color.BLACK);
				canvas.drawOval(x+5, y+0, 60, 60);
				//mouth
				canvas.drawArc(x+18, y+38, 35, 10, 180, 180);
				//eyes
				canvas.fillOval(x+18, y+10, 5, 10);
				canvas.fillOval(x+43, y+10, 5, 10);
				//nose
				canvas.fillOval(x+32, y+28, 5, 7);
				
				//Blue Faces
				canvas.setColor(Color.BLUE);
				canvas.fillOval(x+65, y+0, 60, 60);
				
				canvas.setColor(Color.BLACK);
				canvas.drawOval(x+65,y+0, 60, 60);
				//mouth
				canvas.drawArc(x+78, y+38, 35, 10, 180, 180);
				//eyes
				canvas.fillOval(x+78, y+10, 5, 10);
				canvas.fillOval(x+103, y+10, 5, 10);
				//nose
				canvas.fillOval(x+92, y+28, 5, 7);
			}
		}
	}
}
