package edu.orangecoastcollege.cs170.ssharif4.ic10;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JApplet;

public class LoopyFaces extends JApplet{
	public void init() {
		setSize(610,610);
	}
	
	public void paint(Graphics canvas) {
		for(int x= 5; x<600; x+=120) {
			for(int y=x; y<=x; y+=x) {
				// Yellow faces
				canvas.setColor(Color.ORANGE);
				canvas.fillOval(x, y+0, 60, 60);
				
				canvas.setColor(Color.BLACK);
				canvas.drawOval(x, y+0, 60, 60);
				//mouth
				canvas.drawArc(x+13, y+38, 35, 10, 180, 180);
				//eyes
				canvas.fillOval(x+13, y+10, 5, 10);
				canvas.fillOval(x+43, y+10, 5, 10);
				//nose
				canvas.fillOval(x+29, y+28, 5, 7);
				
				//Blue Faces
				canvas.setColor(Color.BLUE);
				canvas.fillOval(x+60, y+55, 60, 60);
				
				canvas.setColor(Color.BLACK);
				canvas.drawOval(x+60,y+55, 60, 60);
				canvas.drawArc(x+73, y+93, 35, 10, 180, 180);
				//eyes
				canvas.fillOval(x+73, y+65, 5, 10);
				canvas.fillOval(x+103, y+65, 5, 10);
				//nose
				canvas.fillOval(x+87, y+83, 5, 7);
			}
		}
	}
}
