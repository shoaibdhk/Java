package edu.orangecoastcollege.cs170.ssharif4.ic10;

public class NestedShapes {

	public static void main(String[] args) {
		//1st phase
		
		for(int row1 = 1; row1<=4; row1++)
		{
			for (int col1 = 1; col1<=4; col1++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();
		for(int row1 = 1; row1<=4; row1++)
		{
			for (int col1 = 1; col1<=4; col1++) {
				System.out.print(row1);
			}
			System.out.println();
		}
		System.out.println();
		for(int row2 = 1; row2<=4; row2++)
		{
			for (int col2 = 1; col2<=row2; col2++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();
		for(int row2 = 1; row2<=4; row2++)
		{
			for (int col2 = 1; col2<=row2; col2++) {
				System.out.print(row2);
			}
			System.out.println();
		}

	}

}
