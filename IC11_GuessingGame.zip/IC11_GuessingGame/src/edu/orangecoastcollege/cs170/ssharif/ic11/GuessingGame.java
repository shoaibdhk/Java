package edu.orangecoastcollege.cs170.ssharif.ic11;

import java.util.Random;
import java.util.Scanner;

public class GuessingGame
{
    public static void main (String[] args){

        // Declare needed variables
        int answer, guess, sumCorrect=0, numberCorrect=0;
        String answerString, guessString;

        Scanner consoleScanner = new Scanner(System.in);
        Random rng = new Random();

        //Randomely generate a 5- digit answer between 10000 and 99999

        answer = rng.nextInt(90000)+10000;
        answerString = String.valueOf(answer);

        do{
           System.out.print("Please enter a 5-digit code (your guess): ");
           guess= consoleScanner.nextInt();
           guessString = String.valueOf(guess);

           //Loop through the answer one number at a time

           for (int i = 0; i<=4; i++){
               if (answerString.charAt(i) == guessString.charAt(i)){
                   numberCorrect++;
                   sumCorrect+= Character.getNumericValue(answerString.charAt(i));
               }
           }

           System.out.println("Number of digits correct: " + numberCorrect);
           System.out.println("Sum of digits correct: " + sumCorrect);
           numberCorrect=0;
           sumCorrect = 0;

        } while(guess!= answer);
    }
}
