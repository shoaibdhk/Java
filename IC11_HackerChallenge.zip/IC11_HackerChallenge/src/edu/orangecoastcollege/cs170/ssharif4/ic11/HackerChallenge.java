package edu.orangecoastcollege.cs170.ssharif4.ic11;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JApplet;

public class HackerChallenge extends JApplet
{
    public void init(){
        setSize(980,840);
    }
    public void paint(Graphics canvas){
        Color occOrange = new Color(245,146,59);
        Color occBlue = new Color(0,80,161);

        for (int x =0; x < 905; x+=181)
        {
            for(int y=0; y<724; y+=201){
            canvas.setColor(occOrange);
            canvas.fillOval(x+0, y+0, 171, 171);

            canvas.setColor(Color.WHITE);
            canvas.fillOval(x+20, y+20, 131, 131);

            canvas.setColor(occBlue);
            canvas.fillArc(x+25, y+24, 117, 123, 60, 270);

            canvas.setColor(Color.WHITE);
            canvas.fillOval(x+36, y+43, 100, 100);

            canvas.setColor(occBlue);
            canvas.fillArc(x+39, y+49, 96, 89, 70,270);

            canvas.setColor(Color.WHITE);
            canvas.fillOval(x+53, y+66, 78, 67);
            
            canvas.setColor(occBlue);
            canvas.fillArc(x+93, y+30, 30, 42, 133, -170);
            canvas.fillArc(x+85, y+50, 30, 40, 131, -170);
            

            //draw the string "Orange Coast College"
            canvas.setColor(occBlue);
            canvas.drawString("Orange Coast College", x+20, y+190);
            }
        }
    }
}
