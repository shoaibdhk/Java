package edu.orangecoastcollege.cs170.ssharif4.ic13;

public enum CardNetwork {
	AMEX,
	DISCOVER,
	MASTER_CARD,
	VISA
}
