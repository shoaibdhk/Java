package edu.orangecoastcollege.cs170.ssharif4.ic13;

public class CreditCard {
	// 1. Fields
	private CardNetwork mnetwork;
	private String mnumber;
	private String mcardHolder;
	private String mexpirationDate;
	private int msecurityCode;
	
	//2. constructor
	
	public CreditCard(CardNetwork network, String cardHolder, String number, String expirationDate, int securityCode) {
		
		mnetwork = network;
		mcardHolder = cardHolder;
		mexpirationDate = expirationDate;
		mnumber = number;
		msecurityCode = securityCode;
		
	}
	
	// 3. Getters
	
	public CardNetwork getNetwork() {
		return mnetwork;
	}
	
	public String getCardHolder() {
		return mcardHolder;
	}
	
	public String getExpirationDate() {
		return mexpirationDate;
	}
	
	public String getNumber() {
		return mnumber;
	}
	
	// 4. setters
	
	public void setCardHolder(String newCardHolder) {
		mcardHolder = newCardHolder;
	}
	
	//5. toString
	
			public String toString() {
				String output = "Credit Card [" + mnetwork.toString() + ", ************" + mnumber.substring(mnumber.length() - 4) + ", " + mcardHolder + ", " + mexpirationDate + "]";
				return output;
			}
	
	//6. equals
	
	public boolean equals(CreditCard other) {
		if (mcardHolder.equals(other.mcardHolder) && mnumber.equals(other.mnumber) && mnetwork == other.mnetwork && 
				mexpirationDate.equals(other.mexpirationDate) && msecurityCode == other.msecurityCode) 
			return true;
		else
			return false;
		
	
	}
}

