package edu.orangecoastcollege.cs170.ssharif4.ic13;

public class CreditCardDemo {

	public static void main(String[] args) {
		
		CreditCard shoaib = new CreditCard(CardNetwork.VISA, "Shoaib Bin Sharif", "1321 3221 1223 5224", "12/29", 123);
		
		System.out.println(shoaib);
	}

}
