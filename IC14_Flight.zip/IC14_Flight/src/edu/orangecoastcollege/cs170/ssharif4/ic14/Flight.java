package edu.orangecoastcollege.cs170.ssharif4.ic14;

public class Flight {
	
	//1. Fields
	private String mCarrier;
	private double mDuration;
	private int mNumber;
	private PlanType mPlanType;
	private int mPassengers;
	
	//2.Construction
	
	public Flight(String Carrier, int Number, double Duration, PlanType PlanType,int Passengers) {
		
		mCarrier = Carrier;
		mNumber = Number;
		mDuration = Duration;
		mPlanType = PlanType;
		mPassengers = Passengers;
	}
	public Flight(Flight other) {
		
		mCarrier = other.mCarrier;
		mNumber = other.mNumber;
		mDuration = other.mDuration;
		mPlanType = other.mPlanType;
		mPassengers = other.mPassengers;
	}
	
	// 3. Accessors or getters
	
	public String getCarrier() {
		return mCarrier;
	}
	
	public int getNumber() {
		return mNumber;
	}
	
	public double getDuration() {
		return mDuration;
	}
	
	public int getPassenger() {
		return mPassengers;
	}
	
	public PlanType getPlanType() {
		return mPlanType;
	}
	
	
	// 4. setters
	
	public void setCarrier(String newCarrier) {
		
		mCarrier = newCarrier;
	}
	
	
	public void setNumber(int newNumber) {
		
		mNumber = newNumber;
	}
	
	public void setDuration(double newDuration) {
		
		mDuration = newDuration;
	}
	public void setPassengers(int newPassengers) {
		
		mPassengers = newPassengers;
	}
	
	public void setPlanType(PlanType newPlanType) {
		
		mPlanType = newPlanType;
	}
	
	//5. toString()
	
	public String toString() {
		String output = "Flight [Carrier=" + mCarrier +", Number="+mNumber + ", Duration="+ mDuration + ", Plan Type=" + mPlanType + ", " +mPassengers + "]";
		return output;
	}
	
	//6. Equals
	
	public boolean equals(Flight other) {
		if(mCarrier.equals(other.mCarrier) && mDuration == other.mDuration && mNumber ==other.mNumber 
				&& mPlanType == other.mPlanType && mPassengers == other.mPassengers)
			return true;
		else
			return false;
	}
	
	//7. Miscalleneous
	
	public boolean addPassengers(int amount) {
		
		
			
			if(((mPassengers+amount)<=150 && mPlanType== PlanType.AIRBUS_320)||((mPassengers+amount)<=200 && mPlanType == PlanType.BOEING_737))
			{
				mPassengers+=amount;
				return true;
			}
			
			else
				return false;
			
		
	}
	public boolean removePassengers(int amount) {
		
		
		
		if((mPassengers-amount)>=0)
		{
			mPassengers-=amount;
			return true;
		}
		
		else
			return false;
		
		
	}
	
}
