package edu.orangecoastcollege.cs170.ssharif4.ic14;

public enum PlanType {
	
	AIRBUS_320,
	BOEING_737
	
}
