package edu.orangecoastcollege.cs170.ssharif4.ic14;

public class GradeDistribution {
	private int mnumberAs=0;
	private int mnumberBs=0;
	private int mnumberCs=0;
	private int mnumberDs=0;
	private int mnumberFs=0;
	public GradeDistribution(int numberAs, int numberBs, int numberCs, int numberDs,int numberFs) 
	{
		mnumberAs = numberAs;
		mnumberBs = numberBs;
		mnumberCs = numberCs;
		mnumberDs = numberDs;
		mnumberFs = numberFs;
		
	}
	
	public GradeDistribution(GradeDistribution other) {
		
		mnumberAs = other.mnumberAs;
		mnumberBs = other.mnumberBs;
		mnumberCs = other.mnumberCs;
		mnumberDs = other.mnumberDs;
		mnumberFs = other.mnumberFs;
		
	}
	
	public int getPercentAs() {
		return (mnumberAs*100)/(mnumberAs + mnumberBs +mnumberCs +mnumberDs +mnumberFs);
	}
	public int getPercentBs() {
		return (mnumberBs*100)/(mnumberAs + mnumberBs +mnumberCs +mnumberDs +mnumberFs);
	}
	
	public int getPercentCs() {
		return (mnumberCs*100)/(mnumberAs + mnumberBs +mnumberCs +mnumberDs +mnumberFs);
	}
	
	public int getPercentDs() {
		return (mnumberDs*100)/(mnumberAs + mnumberBs +mnumberCs +mnumberDs +mnumberFs);
	}
	
	public int getPercentFs() {
		return (mnumberFs*100)/(mnumberAs + mnumberBs +mnumberCs +mnumberDs +mnumberFs);
	}
	
	public int getNumberOfGrades() {
		return (mnumberAs + mnumberBs +mnumberCs +mnumberDs +mnumberFs);
	}
	
	//setters
	
	public void setNumberAs(int newNumberAs) {
		mnumberAs = newNumberAs;
		
	}
	public void setNumberBs(int newNumberBs) {
		mnumberBs = newNumberBs;
		
	}
	public void setNumberCs(int newNumberCs) {
		mnumberCs = newNumberCs;
		
	}
	public void setNumberDs(int newNumberDs) {
		mnumberDs = newNumberDs;
		
	}
	public void setNumberFs(int newNumberFs) {
		mnumberFs = newNumberFs;
		
	}
	public void setAllGrades(int newNumberAs, int newNumberBs, int newNumberCs, int newNumberDs, int newNumberFs) {
		mnumberAs = newNumberAs;
		mnumberBs = newNumberBs;
		mnumberCs = newNumberCs;
		mnumberDs = newNumberDs;
		mnumberDs = newNumberDs;
	}
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(int i=1; i<=(mnumberAs+mnumberBs +mnumberCs +mnumberDs +mnumberFs); i++) {
			sb.append("*");
		}
		sb.append("\n");
		for(int x=1; x<=mnumberAs;x++) {
			sb.append("*");
		}
		sb.append(" A\n");
		for(int x=1; x<=mnumberBs;x++) {
			sb.append("*");
		}
		sb.append(" B\n");
		for(int x=1; x<=mnumberCs;x++) {
			sb.append("*");
		}
		sb.append(" C\n");
		for(int x=1; x<=mnumberDs;x++) {
			sb.append("*");
		}
		sb.append(" D\n");
		for(int x=1; x<=mnumberFs;x++) {
			sb.append("*");
		}
		sb.append(" F\n");
	
		
		return sb.toString();
	}
	
	public boolean equals(GradeDistribution other) {
		if(mnumberAs==other.mnumberAs && mnumberBs==other.mnumberBs && mnumberCs==other.mnumberCs && mnumberDs==other.mnumberDs && mnumberFs==other.mnumberFs)
			return true;
		else
			return false;
		
			
	}
}
