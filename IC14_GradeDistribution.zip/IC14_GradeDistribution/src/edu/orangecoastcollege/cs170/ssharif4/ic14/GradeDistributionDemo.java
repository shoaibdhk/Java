package edu.orangecoastcollege.cs170.ssharif4.ic14;

public class GradeDistributionDemo {
	public static void main(String[]args) {
		GradeDistribution grade = new GradeDistribution(4, 14, 21, 7, 4);
		System.out.println(grade);
		System.out.println(grade.getPercentAs());
		System.out.println(grade.getPercentBs());
		System.out.println(grade.getPercentCs());
		System.out.println(grade.getPercentDs());
		System.out.println(grade.getPercentFs());
	}
}
